import sys, os
sys.path.append(os.path.dirname(__file__))
import urllib.parse
import re
import requests
import json
import time

UA = "Mozilla/5.0 (Linux; Android 13; Pixel 5 Build/TQ3A.230901.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/144.0.7559.132 Safari/537.36 /OS.Gatu v3.0"
BASE_URL = "https://net52.cc"

# We can save state using a temp file
import xbmcvfs
cookie_file = os.path.join(xbmcvfs.translatePath('special://temp'), 'disneymirror_cookie.json')

def get_cookie():
    try:
        with open(cookie_file, 'r') as f:
            data = json.load(f)
            if time.time() - data.get('time', 0) < 43200:
                return data.get('cookie', '')
    except:
        pass
        
    # Auto-unlock
    new_cookie = unlock_session()
    if new_cookie:
        try:
            with open(cookie_file, 'w') as f:
                json.dump({'cookie': new_cookie, 'time': time.time()}, f)
        except:
            pass
        return new_cookie
        
    return ""

def get_headers(cookie_str=None):
    h = {
        "User-Agent": UA,
        "Referer": f"{BASE_URL}/home",
        "Origin": BASE_URL,
        "Accept": "application/json, text/plain, */*",
    }
    if cookie_str:
        h["Cookie"] = f"t_hash_t={cookie_str}; hd=on; ott=dp"
    return h

def unlock_session():
    # 1. Hit home
    s = requests.Session()
    res1 = s.get(f"{BASE_URL}/mobile/home?app=1", headers={
        "User-Agent": UA,
        "X-Requested-With": "com.netmirror.app"
    }, timeout=8)
    
    addhash_match = re.search(r'data-addhash=["\']([^"\']+)["\']', res1.text)
    if not addhash_match: return None
    addhash = addhash_match.group(1)
    
    # 2. Trigger ad visit
    userver_url = f"https://userver.net52.cc/?hee5={addhash}&a=y&t={time.time()}"
    try:
        s.get(userver_url, headers={"User-Agent": UA, "Referer": f"{BASE_URL}/mobile/home?app=1"}, timeout=5)
    except:
        pass
        
    # 3. Poll verify
    s.cookies.set("ext_name", "ojplmecpdpgccookcobabopnaifgidhf", domain="net52.cc")
    s.cookies.set("addhash", urllib.parse.quote(addhash), domain="net52.cc")
    
    start_time = time.time()
    while time.time() - start_time < 45:
        time.sleep(2)
        try:
            v_res = s.post(f"{BASE_URL}/mobile/verify2.php", data=f"verify={urllib.parse.quote(addhash)}", headers={
                "User-Agent": UA,
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Referer": f"{BASE_URL}/mobile/home"
            }, timeout=5)
            
            for c in s.cookies:
                if c.name == 't_hash_t' and '::99' not in c.value:
                    return urllib.parse.unquote(c.value)
                    
            if "All Done" in v_res.text:
                # Reload home
                s.get(f"{BASE_URL}/mobile/home?app=1", headers={"User-Agent": UA}, timeout=6)
                for c in s.cookies:
                    if c.name == 't_hash_t' and '::99' not in c.value:
                        return urllib.parse.unquote(c.value)
                break
        except:
            pass
            
    return None

def get_poster(id_val):
    return f"https://imgcdn.kim/poster/v/{id_val}.jpg"

def get_posts(cat=""):
    cookies = get_cookie()
    # Fetch trays
    url = f"{BASE_URL}/mobile/home?app=1"
    headers = get_headers(cookies)
    headers["X-Requested-With"] = "XMLHttpRequest"
    
    res = requests.get(url, headers=headers)
    html = res.text
    
    # Try fetching hs version as well
    headers["Cookie"] = headers["Cookie"].replace("ott=nf", "ott=hs").replace("ott=dp", "ott=hs")
    try:
        hs_res = requests.get(url, headers=headers)
        html += hs_res.text
    except:
        pass
        
    results = []
    
    # Simple regex fallback from vega
    tray_sections = html.split('tray-container')
    items_to_fetch = []
    
    for sec in tray_sections[1:]:
        h2_match = re.search(r'<h2[^>]*>([^<]+)<\/h2>', sec)
        title = h2_match.group(1).strip() if h2_match else ""
        
        if not cat or cat.lower() in title.lower() or title.lower() in cat.lower():
            arts = re.findall(r'<article[\s\S]*?<\/article>', sec)
            for art in arts:
                id_m = re.search(r'data-post="([^"]+)"', art)
                img_m = re.search(r'data-src="([^"]+)"', art) or re.search(r'src="([^"]+)"', art)
                alt_m = re.search(r'alt="([^"]*)"', art)
                
                if id_m:
                    vid_id = id_m.group(1)
                    item_title = alt_m.group(1).strip() if alt_m and alt_m.group(1).strip() else ""
                    results.append({
                        'id': vid_id,
                        'title': item_title,
                        'image': (img_m.group(1) if img_m else get_poster(vid_id))
                    })
                    if not item_title:
                        items_to_fetch.append(results[-1])
            if cat and results: break
            
    if items_to_fetch:
        import concurrent.futures
        def fetch_title(item):
            try:
                t = int(time.time())
                p_res = requests.get(f"{BASE_URL}/mobile/hs/post.php?id={item['id']}&t={t}", headers=get_headers(cookies), timeout=4)
                item['title'] = p_res.json().get('title', f"Item {item['id']}")
            except:
                item['title'] = f"Item {item['id']}"
                
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            executor.map(fetch_title, items_to_fetch)
            
    return results

def search(query):
    cookies = get_cookie()
    t = int(time.time())
    url = f"{BASE_URL}/mobile/search.php?s={urllib.parse.quote(query)}&t={t}"
    res = requests.get(url, headers=get_headers(cookies))
    
    try:
        data = res.json().get('searchResult', [])
    except:
        return []
        
    results = []
    for item in data:
        vid_id = str(item.get('id'))
        results.append({
            'id': vid_id,
            'title': item.get('t', ''),
            'image': get_poster(vid_id)
        })
    return results

def get_meta(item_id, title):
    cookies = get_cookie()
    t = int(time.time())
    
    data = {}
    found_prefix = 'hs'
    try:
        with open('C:\\Users\\akshi\\kodi_debug.txt', 'a') as f: f.write(f"Testing prefixes for {item_id}\n")
    except: pass
    
    for prefix in ['hs', 'nf', 'pv', '']:
        post_url = f"{BASE_URL}/mobile/{prefix + '/' if prefix else ''}post.php?id={item_id}&t={t}"
        try:
            res = requests.get(post_url, headers=get_headers(cookies))
            try:
                with open('C:\\Users\\akshi\\kodi_debug.txt', 'a') as f: f.write(f"Prefix {prefix}: {res.status_code} {res.text[:50]}\n")
            except: pass
            data = res.json()
            if data and data.get('title'):
                found_prefix = prefix
                break
        except Exception as e:
            try:
                with open('C:\\Users\\akshi\\kodi_debug.txt', 'a') as f: f.write(f"Prefix {prefix} error: {str(e)}\n")
            except: pass
            
    link_list = []
    if 'season' in data and data['season']:
        for s in data['season']:
            snum = str(s.get('s', s.get('name', '1')))
            link_list.append({
                'title': f"Season {snum}",
                'episodesLink': f"{s.get('id')}|{item_id}|{snum}|{urllib.parse.quote(title)}|{found_prefix}"
            })
    elif 'episodes' in data and data['episodes']:
        link_list.append({
            'title': "Season 1",
            'episodesLink': f"{item_id}|{item_id}|1|{urllib.parse.quote(title)}|{found_prefix}"
        })
    else:
        link_list.append({
            'title': title,
            'directLinks': [{
                'title': title,
                'link': f"{item_id}|{urllib.parse.quote(title)}|{found_prefix}"
            }]
        })
        
    return {'linkList': link_list}

def get_episodes(season_link):
    cookies = get_cookie()
    t = int(time.time())
    
    parts = season_link.split('|')
    sid = parts[0]
    series_id = parts[1]
    snum = parts[2] if len(parts) > 2 else "1"
    title = urllib.parse.unquote(parts[3]) if len(parts) > 3 else "Series"
    prefix = parts[4] if len(parts) > 4 else "hs"
    
    eps = []
    page = 1
    has_more = True
    
    while has_more and page <= 6:
        url = f"{BASE_URL}/mobile/{prefix + '/' if prefix else ''}episodes.php?s={sid}&series={series_id}&t={t}&page={page}"
        res = requests.get(url, headers=get_headers(cookies))
        try:
            data = res.json()
        except:
            break
            
        if data and 'episodes' in data and data['episodes']:
            for ep in data['episodes']:
                ep_id = str(ep.get('id', ''))
                ep_num = str(ep.get('ep', len(eps)+1))
                
                thumb = ""
                if ep_id:
                    if prefix == 'pv': thumb = f"https://img.nfmirrorcdn.top/pvepimg/{ep_id}.jpg"
                    elif prefix == 'hs': thumb = f"https://imgcdn.kim/hsepimg/{ep_id}.jpg"
                    elif prefix == '': thumb = f"https://imgcdn.kim/epimg/{ep_id}.jpg"
                    else: thumb = f"https://imgcdn.kim/poster/v/150/{ep_id}.jpg"
                    
                eps.append({
                    'title': f"Episode {ep_num}: {ep.get('t', '')}",
                    'link': f"{ep_id}|{urllib.parse.quote(title + ' Ep ' + ep_num)}|{prefix}",
                    'thumb': thumb
                })
            if data.get('nextPageShow', 0) > 0:
                page += 1
            else:
                has_more = False
        else:
            has_more = False
            
    return eps

def get_stream(play_link):
    cookies = get_cookie()
    tm = int(time.time())
    
    parts = play_link.split('|')
    vid_id = parts[0]
    title = urllib.parse.unquote(parts[1]) if len(parts)>1 else "Title"
    prefix = parts[2] if len(parts)>2 else "hs"
    
    # 1. Playlist flow
    pl_url = f"{BASE_URL}/mobile/{prefix + '/' if prefix else ''}playlist.php?id={vid_id}&t={urllib.parse.quote(title)}&tm={tm}"
    res = requests.get(pl_url, headers=get_headers(cookies))
    
    try:
        data = res.json()
        if isinstance(data, list): data = data[0]
    except:
        return None
        
    subs = []
    if 'tracks' in data and data['tracks']:
        for t in data['tracks']:
            t_file = t.get('file', '')
            if t_file and t.get('kind', '').lower() in ['captions', 'subtitles']:
                if not t_file.startswith('http'): t_file = BASE_URL + t_file
                subs.append(t_file)
                
    if 'sources' in data and data['sources']:
        for s in data['sources']:
            furl = s.get('file', '')
            if not furl: continue
            if not furl.startswith('http'): furl = BASE_URL + furl
            
            # Simple check for abuse video
            if '220884' in furl:
                # Force cookie refresh
                try: os.remove(cookie_file)
                except: pass
                cookies = get_cookie()
                # Retry once
                res2 = requests.get(pl_url, headers=get_headers(cookies))
                try:
                    data2 = res2.json()
                    if isinstance(data2, list): data2 = data2[0]
                    furl = data2['sources'][0]['file']
                    if not furl.startswith('http'): furl = BASE_URL + furl
                    
                    if 'tracks' in data2 and data2['tracks'] and not subs:
                        for t in data2['tracks']:
                            t_file = t.get('file', '')
                            if t_file and t.get('kind', '').lower() in ['captions', 'subtitles']:
                                if not t_file.startswith('http'): t_file = BASE_URL + t_file
                                subs.append(t_file)
                except:
                    pass
            
            if '220884' not in furl:
                return furl + "|Referer=" + BASE_URL + "/", subs
                
    # Fallback to NewTV
    try:
        ntv_res = requests.get(f"https://tv.imgcdn.kim/newtv/player.php?id={vid_id}", headers={
            "Ott": "hs",
            "X-Requested-With": "NetmirrorNewTV v1.0",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0",
        })
        ntv_data = ntv_res.json()
        if ntv_data.get('status') == 'ok' and ntv_data.get('video_link'):
            subs = []
            if 'subtitle' in ntv_data:
                for sub in ntv_data['subtitle']:
                    subs.append(sub.get('file'))
            return ntv_data['video_link'] + "|Referer=" + (ntv_data.get('referer') or BASE_URL+"/"), subs
    except:
        pass
        
    return None, []
