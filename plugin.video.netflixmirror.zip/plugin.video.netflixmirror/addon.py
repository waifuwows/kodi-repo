import sys
import urllib.parse
import xbmcgui
import xbmcplugin
from resources.lib import disneymirror_scraper

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

action = args.get('action', [None])[0]

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

if action is None:
    url_search = build_url({'action': 'search'})
    li_search = xbmcgui.ListItem('Search')
    li_search.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_search, listitem=li_search, isFolder=True)
    
    url_home = build_url({'action': 'home_menu'})
    li_home = xbmcgui.ListItem('Home')
    li_home.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_home, listitem=li_home, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_menu':
    cats = [
        'Top 10 Today', 'Latest Movies', 'Latest Releases', 'New On Netflix',
        'Action Films', 'Drama Series', 'Exciting TV Shows', 'Crime TV Shows',
        'Comedy Movies', 'Hindi Movies & TV', 'Kids and Family Movies'
    ]
    for cat in cats:
        url = build_url({'action': 'home_cat', 'cat': cat})
        li = xbmcgui.ListItem(cat)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_cat':
    cat = args.get('cat', [''])[0]
    results = disneymirror_scraper.get_posts(cat)
    for res in results:
        url = build_url({'action': 'folders', 'id': res['id'], 'title': res['title']})
        li = xbmcgui.ListItem(res['title'])
        li.setInfo('video', {'title': res['title']})
        if res.get('image'):
            li.setArt({'thumb': res['image'], 'poster': res['image']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'search':
    query = xbmcgui.Dialog().input('Search')
    if query:
        results = disneymirror_scraper.search(query)
        for res in results:
            url = build_url({'action': 'folders', 'id': res['id'], 'title': res['title']})
            li = xbmcgui.ListItem(res['title'])
            li.setInfo('video', {'title': res['title']})
            if res.get('image'):
                li.setArt({'thumb': res['image'], 'poster': res['image']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'folders':
    item_id = args['id'][0]
    title = args['title'][0]
    
    meta = disneymirror_scraper.get_meta(item_id, title)
    
    for link in meta.get('linkList', []):
        if 'episodesLink' in link:
            url = build_url({'action': 'episodes', 'season_link': link['episodesLink']})
            li = xbmcgui.ListItem(link['title'])
            li.setInfo('video', {'title': link['title']})
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        elif 'directLinks' in link:
            for dl in link['directLinks']:
                url = build_url({'action': 'play', 'play_link': dl['link']})
                li = xbmcgui.ListItem(dl['title'])
                li.setInfo('video', {'title': dl['title']})
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
                
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'episodes':
    season_link = args['season_link'][0]
    eps = disneymirror_scraper.get_episodes(season_link)
    
    for ep in eps:
        url = build_url({'action': 'play', 'play_link': ep['link']})
        li = xbmcgui.ListItem(ep['title'])
        li.setInfo('video', {'title': ep['title']})
        if ep.get('thumb'):
            li.setArt({'icon': ep['thumb'], 'thumb': ep['thumb'], 'poster': ep['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'play':
    play_link = args['play_link'][0]
    stream_url, subs = disneymirror_scraper.get_stream(play_link)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        if subs:
            li.setSubtitles(subs)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)
    else:
        xbmcgui.Dialog().notification('Error', 'No playable stream found', xbmcgui.NOTIFICATION_ERROR)
