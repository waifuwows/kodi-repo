import sys
import os
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc

# Ensure resources/lib is in path
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import kartoons_scraper

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

xbmc.log(f"KARTOONS ARGS: {args}", level=xbmc.LOGINFO)

action = args.get('action', [None])[0]

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

CATALOG_MAPPING = {
    'latest_shows': ('Latest Shows', '/catalog/show'),
    'latest_movies': ('Latest Movies', '/catalog/movie'),
    'popular_shows': ('Popular Shows', '/catalog/show?catalog=popular'),
    'popular_movies': ('Popular Movies', '/catalog/movie?catalog=popular')
}

if action is None:
    # Main menu
    url_search = build_url({'action': 'search'})
    li_search = xbmcgui.ListItem('Search')
    li_search.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_search, listitem=li_search, isFolder=True)

    for cat_key, (title, filter_url) in CATALOG_MAPPING.items():
        url = build_url({'action': 'catalog', 'cat': cat_key})
        li = xbmcgui.ListItem(title)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'catalog':
    cat_key = args.get('cat', [None])[0]
    
    # Resolve filter path from key or legacy filter param
    if cat_key in CATALOG_MAPPING:
        filter_path = CATALOG_MAPPING[cat_key][1]
    else:
        filter_path = args.get('filter', ['/catalog/show'])[0]

    page = int(args.get('page', ['1'])[0])
    xbmc.log(f"KARTOONS RESOLVED CAT: {cat_key} -> {filter_path}", level=xbmc.LOGINFO)

    items = kartoons_scraper.get_catalog_items(filter_path, page=page)
    
    for item in items:
        item_id = item.get('id') or item.get('_id')
        item_type = item.get('type', 'show')
        title = item.get('title', 'Unknown')
        poster = item.get('image') or item.get('coverImage') or ''

        if item_type == 'movie':
            url = build_url({'action': 'play', 'id': item_id, 'type': 'movie', 'title': title})
            li = xbmcgui.ListItem(title)
            li.setProperty('IsPlayable', 'true')
            is_folder = False
        else:
            url = build_url({'action': 'show_seasons', 'id': item_id, 'title': title, 'image': poster})
            li = xbmcgui.ListItem(title)
            is_folder = True

        # Exactly like moviebox and hdhub4u: simple thumb and poster
        if poster:
            li.setArt({'thumb': poster, 'poster': poster})
            
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

    # Next page button if items exist
    if len(items) >= 15:
        url_next = build_url({'action': 'catalog', 'cat': cat_key or 'latest_shows', 'filter': filter_path, 'page': page + 1})
        li_next = xbmcgui.ListItem('>> Next Page >>')
        li_next.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_next, listitem=li_next, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'search':
    query = xbmcgui.Dialog().input('Search Kartoons')
    if query:
        items = kartoons_scraper.search(query)
        for item in items:
            item_id = item.get('id') or item.get('_id')
            item_type = item.get('type', 'show')
            title = item.get('title', 'Unknown')
            poster = item.get('image') or item.get('coverImage') or ''

            if item_type == 'movie':
                url = build_url({'action': 'play', 'id': item_id, 'type': 'movie', 'title': title})
                li = xbmcgui.ListItem(title)
                li.setProperty('IsPlayable', 'true')
                is_folder = False
            else:
                url = build_url({'action': 'show_seasons', 'id': item_id, 'title': title, 'image': poster})
                li = xbmcgui.ListItem(title)
                is_folder = True

            if poster:
                li.setArt({'thumb': poster, 'poster': poster})

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

        xbmcplugin.endOfDirectory(addon_handle)

elif action == 'show_seasons':
    show_id = args.get('id', [None])[0]
    show_title = args.get('title', ['Show'])[0]
    show_image = args.get('image', [''])[0]

    show = kartoons_scraper.get_show_details(show_id)
    seasons = show.get('seasons', []) if show else []

    if len(seasons) <= 1:
        # If only 1 season, directly show episodes
        season = seasons[0] if seasons else {}
        season_slug = season.get('slug') or ('season-' + str(season.get('seasonNumber', 1)))
        episodes = kartoons_scraper.get_season_episodes(show_id, season_slug)
        for ep in episodes:
            ep_id = ep.get('_id') or ep.get('id')
            ep_num = ep.get('episodeNumber', '')
            ep_title = ep.get('title', '')
            label = f"E{ep_num}: {ep_title}" if ep_title else f"Episode {ep_num}"
            ep_img = ep.get('image') or show_image

            url = build_url({'action': 'play', 'id': ep_id, 'type': 'episode', 'title': label})
            li = xbmcgui.ListItem(label)
            li.setProperty('IsPlayable', 'true')
            if ep_img:
                li.setArt({'thumb': ep_img, 'poster': ep_img})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    else:
        for season in seasons:
            s_num = season.get('seasonNumber', 1)
            s_title = season.get('title') or f"Season {s_num}"
            s_slug = season.get('slug') or f"season-{s_num}"
            url = build_url({'action': 'episodes', 'show_id': show_id, 'season_slug': s_slug, 'show_image': show_image})
            li = xbmcgui.ListItem(s_title)
            if show_image:
                li.setArt({'thumb': show_image, 'poster': show_image})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'episodes':
    show_id = args.get('show_id', [None])[0]
    season_slug = args.get('season_slug', [None])[0]
    show_image = args.get('show_image', [''])[0]

    episodes = kartoons_scraper.get_season_episodes(show_id, season_slug)
    for ep in episodes:
        ep_id = ep.get('_id') or ep.get('id')
        ep_num = ep.get('episodeNumber', '')
        ep_title = ep.get('title', '')
        label = f"E{ep_num}: {ep_title}" if ep_title else f"Episode {ep_num}"
        ep_img = ep.get('image') or show_image

        url = build_url({'action': 'play', 'id': ep_id, 'type': 'episode', 'title': label})
        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        if ep_img:
            li.setArt({'thumb': ep_img, 'poster': ep_img})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'play':
    content_id = args.get('id', [None])[0]
    content_type = args.get('type', ['episode'])[0]
    is_movie = (content_type == 'movie')

    streams = kartoons_scraper.get_streams(content_id, is_movie=is_movie)
    if streams:
        stream = streams[0]
        play_item = xbmcgui.ListItem(path=stream['url'])
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        if stream.get('subtitles'):
            play_item.setSubtitles(stream['subtitles'])
            
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('Error', 'Could not resolve stream links', xbmcgui.NOTIFICATION_ERROR)
