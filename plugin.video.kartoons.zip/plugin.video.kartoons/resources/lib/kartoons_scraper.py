import random
import requests
import json
import urllib.parse

API_BASE = "https://api.kartoons.to/api/cloudstream"
WEB_API_BASE = "https://api.kartoons.to/api"

HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://kartoons.to/",
    "Origin": "https://kartoons.to",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

# Hardcoded pool of authenticated device tokens
TOKENS = [
    "BDRPJfIpnkzbfFTNZcHBNkS2bEND9wLxpX53ZYFLTkU",
    "05xsaqu74_5N_qs4A08417csWP9hxljirKTKpLUNS68"
]

def request_api(endpoint, params=None, need_token=False, base=API_BASE):
    if params is None:
        params = {}
    if need_token:
        tokens_to_try = list(TOKENS)
        random.shuffle(tokens_to_try)
        for tok in tokens_to_try:
            params['token'] = tok
            try:
                r = requests.get(f"{base}{endpoint}", params=params, headers=HEADERS, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    if data.get("success") and not data.get("auth_required"):
                        return data
            except Exception:
                continue
        return None
    else:
        try:
            r = requests.get(f"{base}{endpoint}", params=params, headers=HEADERS, timeout=15)
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return None

def get_home_catalogs():
    return [
        {"title": "Latest Shows", "filter": "/catalog/show"},
        {"title": "Latest Movies", "filter": "/catalog/movie"},
        {"title": "Popular Shows", "filter": "/catalog/show?catalog=popular"},
        {"title": "Popular Movies", "filter": "/catalog/movie?catalog=popular"}
    ]

def get_catalog_items(filter_path, page=1):
    endpoint = filter_path
    params = {"page": page}
    if "?" in endpoint:
        endpoint, q = endpoint.split("?", 1)
        for pair in q.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                params[k] = v
                
    res = request_api(endpoint, params=params)
    if res and "data" in res:
        return res["data"]
    return []

def search(query):
    """
    Uses the website's exact fuzzy search endpoints:
      - https://api.kartoons.to/api/shows?search=...
      - https://api.kartoons.to/api/movies?search=...
    """
    results = []
    
    # 1. Search Shows
    try:
        r_shows = request_api("/shows", params={"search": query, "page": 1, "limit": 20}, base=WEB_API_BASE)
        if r_shows and "data" in r_shows:
            for item in r_shows["data"]:
                item["type"] = "show"
                results.append(item)
    except Exception:
        pass
        
    # 2. Search Movies
    try:
        r_movies = request_api("/movies", params={"search": query, "page": 1, "limit": 20}, base=WEB_API_BASE)
        if r_movies and "data" in r_movies:
            for item in r_movies["data"]:
                item["type"] = "movie"
                results.append(item)
    except Exception:
        pass

    # Fallback to cloudstream search if both returned empty
    if not results:
        res = request_api("/search", params={"q": query})
        if res and "data" in res:
            results = res["data"]

    return results

def get_show_details(show_id):
    res = request_api(f"/show/{show_id}")
    if res and "data" in res:
        return res["data"]
    return None

def get_season_episodes(show_id, season_slug):
    res = request_api(f"/show/{show_id}/season/{urllib.parse.quote(season_slug)}/episodes")
    if res and "data" in res:
        return res["data"]
    return []

def get_streams(content_id, is_movie=False):
    endpoint = f"/movie/{content_id}/links" if is_movie else f"/episode/{content_id}/links"
    res = request_api(endpoint, need_token=True)
    if not res or "data" not in res:
        return []
        
    data = res["data"]
    links = data.get("links", [])
    subtitles = data.get("subtitles", [])
    
    results = []
    for link in links:
        url = link.get("url")
        if not url:
            continue
            
        headers_str = urllib.parse.urlencode({
            'User-Agent': HEADERS['User-Agent'],
            'Referer': 'https://kartoons.to/'
        })
        playable_url = f"{url}|{headers_str}"
        
        results.append({
            "name": link.get("name", "Kartoons Stream"),
            "url": playable_url,
            "subtitles": [sub.get("url") for sub in subtitles if sub.get("url")]
        })
        
    return results
