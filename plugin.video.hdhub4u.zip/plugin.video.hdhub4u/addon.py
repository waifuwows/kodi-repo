import sys
import os
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc

# Add resources/lib to sys.path so imports work flawlessly
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import hdhub4u_scraper

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

xbmc.log(f"HDHUB4U ARGV: {sys.argv}", level=xbmc.LOGINFO)
xbmc.log(f"HDHUB4U ARGS: {args}", level=xbmc.LOGINFO)

action = args.get('action', [None])[0]
xbmc.log(f"HDHUB4U ACTION: {action}", level=xbmc.LOGINFO)

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

if action is None:
    # Main menu
    url_search = build_url({'action': 'search'})
    li_search = xbmcgui.ListItem('Search')
    li_search.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_search, listitem=li_search, isFolder=True)
    
    url_home = build_url({'action': 'home_menu'})
    li_home = xbmcgui.ListItem('Home')
    li_home.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_home, listitem=li_home, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_menu':
    cats = [
        ('Latest', ''),
        ('Web Series', '/category/web-series'),
        ('Hollywood', '/category/hollywood-movies'),
        ('South Movies', '/category/south-hindi-movies')
    ]
    for title, path in cats:
        url = build_url({'action': 'home_cat', 'path': path})
        li = xbmcgui.ListItem(title)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_cat':
    path = args.get('path', [''])[0]
    results = hdhub4u_scraper.get_home(path)
    for item in results:
        url = build_url({'action': 'episodes', 'url': item['url']})
        li = xbmcgui.ListItem(item['title'])
        if item.get('poster'): li.setArt({'thumb': item['poster'], 'poster': item['poster']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'search':
    query = xbmcgui.Dialog().input('Search HDHub4u')
    if query:
        results = hdhub4u_scraper.search(query)
        for res in results:
            url = build_url({'action': 'episodes', 'url': res['slug']})
            li = xbmcgui.ListItem(res['title'])
            if res.get('poster'):
                li.setArt({'thumb': res['poster'], 'poster': res['poster']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'episodes':
    page_url = args['url'][0]
    links = hdhub4u_scraper.get_episodes(page_url)
    for i, link in enumerate(links):
        url = build_url({'action': 'play', 'link': link['id']})
        li = xbmcgui.ListItem(f"{link['title']} (Link {i+1})")
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'play':
    link = args['link'][0]
    stream_url = hdhub4u_scraper.get_stream(link)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)
    else:
        xbmcgui.Dialog().notification('Error', 'No playable stream found', xbmcgui.NOTIFICATION_ERROR)
