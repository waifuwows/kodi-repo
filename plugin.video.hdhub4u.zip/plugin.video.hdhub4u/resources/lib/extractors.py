import requests
import re
import json
import base64
from bs4 import BeautifulSoup

def rot13(s):
    result = []
    for char in s:
        if 'a' <= char <= 'z':
            result.append(chr(((ord(char) - ord('a') + 13) % 26) + ord('a')))
        elif 'A' <= char <= 'Z':
            result.append(chr(((ord(char) - ord('A') + 13) % 26) + ord('A')))
        else:
            result.append(char)
    return ''.join(result)

def safe_atob(s):
    try:
        return base64.b64decode(s).decode('utf-8')
    except:
        return None

def decode_string(encrypted_str):
    if not encrypted_str:
        return None
    try:
        decoded = base64.b64decode(encrypted_str).decode('utf-8')
        decoded = base64.b64decode(decoded).decode('utf-8')
        decoded = rot13(decoded)
        decoded = base64.b64decode(decoded).decode('utf-8')
        return json.loads(decoded)
    except:
        return None

def extract_url_from_script(html):
    double_atob = re.search(r'(?:var|let|const)\s+\w+\s*=\s*atob\(atob\([\'"]([^\'"]+)[\'"]\)\)', html)
    if double_atob:
        try:
            return base64.b64decode(base64.b64decode(double_atob.group(1))).decode('utf-8')
        except:
            pass
            
    plain_match = re.search(r'var\s+url\s*=\s*[\'"]([^\'"]+)[\'"]', html)
    if plain_match:
        val = plain_match.group(1)
        if 'r=' in val:
            try:
                return base64.b64decode(val.split('r=')[1]).decode('utf-8')
            except:
                pass
        return val
    return ""

def hubcloud_extractor(link, headers):
    session = requests.Session()
    session.headers.update(headers)
    
    hubdrive_link = ""
    current_link = link
    
    if "hubcloud" in link or "/drive/" in link:
        # direct hubcloud link
        pass
    elif "hubdrive" in link:
        try:
            res = session.get(link)
            soup = BeautifulSoup(res.text, 'html.parser')
            btn = soup.select_one('.btn.btn-primary.btn-user.btn-success1.m-1')
            if btn and btn.get('href'):
                hubdrive_link = btn['href']
            else:
                hubdrive_link = link
        except:
            pass
    else:
        # Page link resolver
        try:
            res = session.get(current_link)
            text = res.text
            
            reurl_match = re.search(r'var\s+reurl\s*=\s*["\']([^"\']+)["\']', text, re.I)
            if reurl_match:
                current_link = reurl_match.group(1)
                res = session.get(current_link, headers={'Referer': link})
                text = res.text
                
            enc_match = text.split("s('o','")
            if len(enc_match) > 1:
                encrypted_str = enc_match[1].split("',180")[0]
                decoded = decode_string(encrypted_str)
                if decoded and 'o' in decoded:
                    next_url = safe_atob(decoded['o'])
                    if next_url:
                        current_link = next_url
                        res = session.get(current_link, headers={'Referer': current_link})
                        text = res.text
                        
            soup = BeautifulSoup(text, 'html.parser')
            drive_links = []
            for a in soup.select('a[href*="hubcloud"][href*="/drive/"], a[href*="hubdrive"]'):
                href = a.get('href')
                if not href: continue
                txt = (a.text + (a.parent.text if a.parent else "")).lower()
                q = "Unknown"
                if "2160p" in txt or "4k" in txt: q = "4k"
                elif "1080p" in txt: q = "1080p"
                elif "720p" in txt: q = "720p"
                elif "480p" in txt: q = "480p"
                drive_links.append({'quality': q, 'link': href})
                
            q_order = {"4k": 4, "1080p": 3, "720p": 2, "480p": 1, "Unknown": 0}
            drive_links.sort(key=lambda x: q_order.get(x['quality'], 0), reverse=True)
            
            if drive_links:
                hubdrive_link = drive_links[0]['link']
            else:
                m = re.search(r'href="(https://hubcloud\.[^/]+/drive/[^"]+)"', text)
                if m:
                    hubdrive_link = m.group(1)
                    
            if not hubdrive_link and ("hubcloud" in current_link or "hubdrive" in current_link):
                hubdrive_link = current_link
                
            if "hubdrive" in hubdrive_link:
                res = session.get(hubdrive_link)
                soup = BeautifulSoup(res.text, 'html.parser')
                btn = soup.select_one('.btn.btn-primary.btn-user.btn-success1')
                if btn and btn.get('href'):
                    hubdrive_link = btn['href']
                    
        except:
            pass
            
    hubcloud_link = hubdrive_link
    if hubdrive_link:
        try:
            res = session.get(hubdrive_link)
            m = re.search(r'<META HTTP-EQUIV="refresh" content="0; url=([^"]+)">', res.text, re.I)
            if m:
                hubcloud_link = m.group(1)
        except:
            pass

    # Actually resolve the Hubcloud link
    if not hubcloud_link:
        return None
        
    try:
        res = session.get(hubcloud_link)
        text = res.text
        soup = BeautifulSoup(text, 'html.parser')
        
        vcloud_link = extract_url_from_script(text)
        if not vcloud_link:
            btn = soup.select_one('.fa-file-download.fa-lg')
            if btn and btn.parent and btn.parent.get('href'):
                vcloud_link = btn.parent['href']
                
        if not vcloud_link:
            return None
            
        if "hubcloud" in vcloud_link or "/drive/" in vcloud_link:
            # it might be another hop
            res2 = session.get(vcloud_link, headers={'Referer': hubcloud_link})
            text2 = res2.text
            vcloud_link_script = extract_url_from_script(text2)
            if not vcloud_link_script:
                soup2 = BeautifulSoup(text2, 'html.parser')
                btn2 = soup2.select_one('.fa-file-download.fa-lg')
                if btn2 and btn2.parent and btn2.parent.get('href'):
                    vcloud_link_script = btn2.parent['href']
            vcloud_link = vcloud_link_script
            
        return vcloud_link
    except:
        return None

import pyaes

def _unpad(s):
    return s[:-ord(s[len(s)-1:])]

def _aes_cbc_decrypt(ct_hex, key_bytes, iv_bytes):
    try:
        ct = bytes.fromhex(ct_hex)
        dec = b''
        aes = pyaes.AESModeOfOperationCBC(key_bytes, iv=iv_bytes)
        for i in range(0, len(ct), 16):
            dec += aes.decrypt(ct[i:i+16])
        return _unpad(dec).decode('utf-8')
    except Exception as e:
        return None

def hubstream_extractor(url, headers):
    host_match = re.search(r'^(https?://[^/#?]+)', url)
    host = host_match.group(1) if host_match else 'https://hubstream.art'
    
    tail = url.split('#')[-1]
    hash_val = tail.split('/')[-1] if '/' in tail else tail
    if not hash_val:
        return None
        
    api_url = f"{host}/api/v1/video?id={hash_val}"
    session = requests.Session()
    session.headers.update(headers)
    session.headers.update({'Referer': url})
    
    try:
        res = session.get(api_url)
        enc = res.text.strip()
        if not enc or not all(c in '0123456789abcdefABCDEF' for c in enc) or len(enc) % 32 != 0:
            return None
            
        key = b'kiemtienmua911ca'
        ivs = [b'1234567890oiuytr', b'0123456789abcdef']
        
        for iv in ivs:
            pt = _aes_cbc_decrypt(enc, key, iv)
            if pt:
                m = re.search(r'"source":"([^"]+)"', pt)
                if m:
                    file = m.group(1).replace('\\/', '/')
                    if file.startswith('http'):
                        return file
        return None
    except:
        return None
