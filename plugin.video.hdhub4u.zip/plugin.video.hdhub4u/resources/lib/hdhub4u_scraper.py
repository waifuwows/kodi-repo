import urllib.parse
import re
import requests
from bs4 import BeautifulSoup
import extractors

SITE = 'https://new5.hdhub4u.cl'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

def search(query):
    # HDHub4u doesn't have a reliable simple ?s= search always, but usually it does.
    # We will use the Typesense API if we can, or fallback to standard ?s=
    url = f"{SITE}/?s={urllib.parse.quote(query)}"
    headers = {'User-Agent': UA, 'Cookie': 'xla=s4t'}
    try:
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        results = []
        for article in soup.select('article, .post-item, .item, li.thumb, figure'):
            a_tag = article.find('a')
            if not a_tag: continue
            href = a_tag.get('href')
            if not href or '/category/' in href or '/page/' in href: continue
            
            img_tag = article.find('img')
            poster = img_tag.get('src') if img_tag else ''
            
            p = article.select_one('figcaption p')
            if p:
                raw_title = p.text
            else:
                raw_title = img_tag.get('alt', '') if img_tag else 'Untitled'
                if not raw_title:
                    for a in article.find_all('a'):
                        if a.text.strip():
                            raw_title = a.text.strip()
                            break
                
            title = re.sub(r'^\s*download\s+', '', raw_title, flags=re.I)
            title = re.split(r'\s*\(', title)[0]
            title = re.split(r'\bseason\b', title, flags=re.I)[0]
            title = re.sub(r'\b(480p|720p|1080p|2160p|4k|web[- ]?dl|hdrip|bluray|x264|x265|hevc|hindi|dual audio).*$', '', title, flags=re.I).strip()
            
            results.append({
                'slug': href,
                'title': title or 'Untitled',
                'poster': poster
            })
        return results
    except Exception as e:
        import xbmc
        xbmc.log(f"HDHub4u search error: {e}", level=xbmc.LOGERROR)
        return []

def get_episodes(url):
    # Since HDHub4u posts are usually single movies or a whole season ZIP/pack,
    # we just fetch the links on the page. We will present each link as a "Stream/Episode"
    headers = {'User-Agent': UA, 'Cookie': 'xla=s4t'}
    try:
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        links = []
        for a in soup.select('a[href*="hubcloud"], a[href*="/drive/"], a[href*="hubdrive"], a[href*="hubstream"]'):
            href = a.get('href')
            if not href: continue
            
            text_context = (a.text + (a.parent.text if a.parent else "") + (a.parent.parent.text if a.parent and a.parent.parent else "")).lower()
            quality = "Link"
            if "2160p" in text_context or "4k" in text_context: quality = "4K"
            elif "1080p" in text_context: quality = "1080p"
            elif "720p" in text_context: quality = "720p"
            elif "480p" in text_context: quality = "480p"
            
            if "hubstream" in href:
                quality += " [HubStream]"
                
            links.append({
                'id': href,
                'title': f"{quality} Stream"
            })
            
        # Deduplicate while preserving order
        seen = set()
        unique_links = []
        for l in links:
            if l['id'] not in seen:
                seen.add(l['id'])
                unique_links.append(l)
                
        return unique_links
    except Exception as e:
        print(f"HDHub4u get_episodes error: {e}")
        return []

def get_stream(link):
    headers = {'User-Agent': UA, 'Cookie': 'xla=s4t'}
    if 'hubstream' in link.lower():
        from extractors import hubstream_extractor
        stream_url = hubstream_extractor(link, headers)
    else:
        from extractors import hubcloud_extractor
        stream_url = hubcloud_extractor(link, headers)
        
    if stream_url:
        return f"{stream_url}|User-Agent={urllib.parse.quote(UA)}"
    return None

def get_home(category_path=""):
    url = f"{SITE}{category_path}"
    headers = {'User-Agent': UA, 'Cookie': 'xla=s4t'}
    resp = requests.get(url, headers=headers)
    import xbmc
    xbmc.log(f"HDHUB4U SCRAPER GET {url} STATUS: {resp.status_code}", level=xbmc.LOGINFO)
    if resp.status_code != 200:
        xbmc.log(f"HDHUB4U SCRAPER CONTENT: {resp.text[:200]}", level=xbmc.LOGINFO)
        return []
    soup = BeautifulSoup(resp.text, 'html.parser')
    results = []
    
    for article in soup.select('article, .post-item, .item, li.thumb, figure'):
        a_tag = article.find('a')
        if not a_tag: continue
        link = a_tag.get('href')
        
        # Title can be in img alt or a text
        img_tag = article.find('img')
        poster = img_tag.get('src') if img_tag else ''
        title = ''
        if img_tag and img_tag.get('alt'):
            title = img_tag.get('alt')
        else:
            # Try to find an a tag with text (e.g. inside figcaption)
            for a in article.find_all('a'):
                if a.text.strip():
                    title = a.text.strip()
                    break
        
        if title and link:
            results.append({'title': title, 'url': link, 'poster': poster})
    return results
