import sys
import urllib.parse
import xbmcgui
import xbmcplugin
from resources.lib import hianime_scraper

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])


action = args.get('action', [None])[0]

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

if action is None:
    url_search = build_url({'action': 'search'})
    li_search = xbmcgui.ListItem('Search')
    li_search.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_search, listitem=li_search, isFolder=True)
    url_home = build_url({'action': 'home_menu'})
    li_home = xbmcgui.ListItem('Home')
    li_home.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_home, listitem=li_home, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_menu':
    cats = [('Recently Updated', '/recently-updated'), ('Trending', '/most-popular'), ('Top Airing', '/top-airing')]
    for title, path in cats:
        url = build_url({'action': 'home_cat', 'path': path})
        li = xbmcgui.ListItem(title)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_cat':
    
    path = args.get('path', [''])[0]
    results = hianime_scraper.get_home(path)
    for item in results:
        url = build_url({'action': 'folders', 'slug': item['url'].split('/')[-1]})
        li = xbmcgui.ListItem(item['title'])
        if item.get('poster'): li.setArt({'thumb': item['poster'], 'poster': item['poster']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'search':
    
    query = xbmcgui.Dialog().input('Search')
    if query:
        results = hianime_scraper.search(query)
        for res in results:
            url = build_url({'action': 'folders', 'slug': res['slug']})
            li = xbmcgui.ListItem(res['title'])
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'folders':
    slug = args['slug'][0]
    
    url_sub = build_url({'action': 'episodes', 'slug': slug, 'lang': 'sub'})
    li_sub = xbmcgui.ListItem("Episodes (Sub)")
    li_sub.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_sub, listitem=li_sub, isFolder=True)
    
    url_dub = build_url({'action': 'episodes', 'slug': slug, 'lang': 'dub'})
    li_dub = xbmcgui.ListItem("Episodes (Dub)")
    li_dub.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_dub, listitem=li_dub, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'episodes':
    slug = args['slug'][0]
    lang = args.get('lang', ['sub'])[0]
    episodes = hianime_scraper.get_episodes(slug, lang_type=lang)
    for ep in episodes:
        # e.g., ep['id'] = "sub|episodeId", ep['number'] = "1"
        url = build_url({'action': 'play', 'ep_id': ep['id']})
        li = xbmcgui.ListItem(f"Episode {ep['number']}")
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'play':
    ep_id = args['ep_id'][0]
    stream_url = hianime_scraper.get_stream(ep_id)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)
    else:
        xbmcgui.Dialog().notification('Error', 'No playable stream found', xbmcgui.NOTIFICATION_ERROR)





