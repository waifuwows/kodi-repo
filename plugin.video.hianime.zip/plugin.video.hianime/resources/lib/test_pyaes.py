import sys
import pyaes

MEGA_AES_KEY = b'i?LMTAx0Q6,:}50U'
MEGA_AES_IV = b"W0;27ToaUpl_P%'c"

key = MEGA_AES_KEY.ljust(32, b'\x00')
iv = MEGA_AES_IV.ljust(16, b'\x00')
encrypter = pyaes.Encrypter(pyaes.AESModeOfOperationCBC(key, iv=iv))
ciphertext = encrypter.feed(b'test message inside json') + encrypter.feed()

decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv=iv))
plaintext = decrypter.feed(ciphertext) + decrypter.feed()
print(plaintext)
