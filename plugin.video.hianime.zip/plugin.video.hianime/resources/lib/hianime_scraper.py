import sys, os
sys.path.append(os.path.dirname(__file__))
import urllib.parse
import re
import requests
import json
import base64
import urllib.parse
import pyaes
from bs4 import BeautifulSoup

SITE = 'https://hianime.at'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

MEGA_AES_KEY = b'i?LMTAx0Q6,:}50U'
MEGA_AES_IV = b"W0;27ToaUpl_P%'c"
ZOKO_KEY = "otaku-embed-v1"

def _aes_decrypt(encrypted_text_b64):
    try:
        encrypted_text_b64 = encrypted_text_b64.replace('-', '+').replace('_', '/')
        encrypted_data = base64.b64decode(encrypted_text_b64 + '===')
        
        key = MEGA_AES_KEY.ljust(32, b'\x00')
        iv = MEGA_AES_IV.ljust(16, b'\x00')
        decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv=iv))
        decrypted = decrypter.feed(encrypted_data) + decrypter.feed()
        return json.loads(decrypted.decode('utf-8'))
    except Exception as e:
        return None

def _zoko_decrypt(blob):
    try:
        bytes_data = base64.b64decode(blob)
        out = []
        for i in range(len(bytes_data)):
            # Using Python bitwise XOR
            out.append(bytes_data[i] ^ ord(ZOKO_KEY[i % len(ZOKO_KEY)]))
        return json.loads(bytes(out).decode('utf-8'))
    except:
        return None

def search(query):
    url = f"{SITE}/search?keyword={urllib.parse.quote(query)}"
    headers = {'User-Agent': UA, 'Referer': f"{SITE}/"}
    response = requests.get(url, headers=headers)
    results = []
    
    if response.status_code != 200:
        return results

    html = response.text
    # Results only: split at film_list-wrap to avoid sidebar Top 10
    if 'film_list-wrap' not in html:
        return results
    html = html[html.find('film_list-wrap'):]
    
    chunks = html.split('class="flw-item')
    for chunk in chunks[1:]:
        match = re.search(r'href="[^"]*\/(?:watch\/)?([a-z0-9][a-z0-9-]*-\d+)(?:\?[^"]*)?"', chunk, re.I)
        if not match:
            continue
        slug = match.group(1)
        
        img_match = re.search(r'<img\b[^>]*film-poster-img[^>]*>', chunk, re.I)
        if img_match:
            img_tag = img_match.group(0)
            title_match = re.search(r'alt="([^"]+?)(?:\s+Poster)?"', img_tag, re.I)
            title = title_match.group(1) if title_match else slug
        else:
            title = slug
            
        results.append({
            'slug': slug,
            'title': title
        })
    return results

def get_episodes(slug, lang_type=None):
    anime_id_match = re.search(r'-(\d+)$', slug)
    if not anime_id_match:
        return []
    anime_id = anime_id_match.group(1)
    
    url = f"{SITE}/ajax/episode/list/{anime_id}"
    headers = {'User-Agent': UA, 'Referer': f"{SITE}/watch/{slug}", 'X-Requested-With': 'XMLHttpRequest'}
    response = requests.get(url.replace('/ajax/episode/list', '/api/theme/episode/list'), headers=headers)
    
    try:
        j = response.json()
        html_result = j.get('html', '')
    except:
        html_result = ''
        
    episodes = []
    chunks = html_result.split('ep-item')
    for chunk in chunks[1:]:
        data_id_match = re.search(r'data-id="(\d+)"', chunk)
        data_num_match = re.search(r'data-number="(\d+)"', chunk)
        
        if data_id_match and data_num_match:
            ep_id = data_id_match.group(1)
            num = data_num_match.group(1)
            
            title_match = re.search(r'title="([^"]*)"', chunk)
            title_text = title_match.group(1) if title_match else f"Episode {num}"
            
            # Since HiAnime episode list doesn't explicitly flag sub/dub reliably in the list HTML,
            # we just generate the requested type directly.
            if lang_type is None or lang_type == 'sub':
                episodes.append({
                    'id': f"sub|{ep_id}",
                    'number': f"{num}"
                })
            if lang_type is None or lang_type == 'dub':
                episodes.append({
                    'id': f"dub|{ep_id}",
                    'number': f"{num}"
                })
            
    return episodes

def get_stream(ep_id_str):
    # ep_id_str format is "type|epId"
    parts = ep_id_str.split('|', 1)
    if len(parts) != 2:
        return None
    req_type, ep_id = parts
    
    servers_url = f"{SITE}/api/theme/episode/servers?episodeId={ep_id}"
    headers = {'User-Agent': UA, 'Referer': f"{SITE}/watch/", 'X-Requested-With': 'XMLHttpRequest'}
    
    response = requests.get(servers_url, headers=headers)
    try:
        html = response.json().get('html', '')
    except:
        return None

    servers = []
    matches = re.finditer(r'data-type="(\w+)"[\s\S]{0,200}?data-server-name="([^"]+)"[\s\S]{0,200}?data-hash="([^"]+)"', html)
    for m in matches:
        t = m.group(1)
        name = m.group(2)
        b64_url = m.group(3)
        try:
            # Correct base64 decode mapping logic
            b64_url = b64_url.replace('-', '+').replace('_', '/')
            url = base64.b64decode(b64_url + '===').decode('utf-8')
            servers.append({'type': t, 'name': name, 'url': url})
        except:
            pass

    # Filter by sub/dub
    wanted = []
    for srv in servers:
        if req_type == 'dub':
            if srv['type'] == 'dub': wanted.append(srv)
        else:
            if srv['type'] in ('sub', 'hsub'): wanted.append(srv)

    # Rank servers: VidPlay > Zoko > MegaPlay
    def srv_rank(name):
        n = name.lower()
        if 'vidplay' in n: return 0
        if 'zoko' in n: return 1
        if 'vidstream' in n: return 2
        if 'hd' in n: return 3
        return 5

    wanted.sort(key=lambda x: srv_rank(x['name']))

    for srv in wanted:
        url = srv['url']
        
        # Is it Zoko?
        if 'zokoanime' in url.lower():
            zoko_resp = requests.get(url, headers={'User-Agent': UA, 'Referer': f"{SITE}/"})
            blob_match = re.search(r'window\.__P\s*=\s*"([^"]+)"', zoko_resp.text)
            if blob_match:
                cfg = _zoko_decrypt(blob_match.group(1))
                if cfg and cfg.get('src'):
                    return f"{cfg['src']}|Referer={url}&User-Agent={urllib.parse.quote(UA)}"
            continue
            
        # Standard player (VidPlay / MegaPlay)
        data_id_match = re.search(r'/e/([a-zA-Z0-9_-]+)', url)
        if not data_id_match:
            continue
        embed_data_id = data_id_match.group(1)
        embed_base = re.search(r'^(https?://[^/]+)', url).group(1)
        
        path = '/stream/getSourcesNew' if 'megaplay' in url.lower() else '/stream/getSources'
        sources_url = f"{embed_base}{path}?id={embed_data_id}&type={req_type}"
        embed_headers = {'User-Agent': UA, 'Referer': url, 'X-Requested-With': 'XMLHttpRequest'}
        
        src_resp = requests.get(sources_url, headers=embed_headers)
        try:
            src_data = src_resp.json()
        except:
            continue
            
        if 'enc' in src_data:
            decrypted = _aes_decrypt(src_data['enc'])
            if decrypted and 'sources' in decrypted:
                src_obj = decrypted['sources'][0] if isinstance(decrypted['sources'], list) else decrypted['sources']
                if src_obj and src_obj.get('file'):
                    return f"{src_obj['file']}|Referer={url}&User-Agent={urllib.parse.quote(UA)}"
                    
        elif 'sources' in src_data:
            src_obj = src_data['sources'][0] if isinstance(src_data['sources'], list) else src_data['sources']
            if src_obj and src_obj.get('file'):
                return f"{src_obj['file']}|Referer={url}&User-Agent={urllib.parse.quote(UA)}"
                
    return None

def get_home(path=""):
    resp = requests.get(f"{SITE}{path}", headers={'User-Agent': UA})
    if resp.status_code != 200: return []
    soup = BeautifulSoup(resp.text, 'html.parser')
    results = []
    for item in soup.select('.flw-item'):
        a_tag = item.find('a', class_='film-poster-ahref')
        if not a_tag: continue
        title = a_tag.get('title')
        link = a_tag.get('href')
        if link and not link.startswith('http'): link = SITE + link
        img = item.find('img', class_='film-poster-img')
        poster = img.get('data-src') or img.get('src') if img else ''
        if title and link: results.append({'title': title, 'url': link, 'poster': poster})
    return results


