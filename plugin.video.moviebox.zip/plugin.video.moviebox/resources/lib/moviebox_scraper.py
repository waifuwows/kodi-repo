import urllib.parse
import requests
import json

API_BASE = 'https://h5-api.aoneroom.com'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

_auth_token = None

def _get_headers():
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json',
        'Origin': 'https://moviebox.ph',
        'Referer': 'https://moviebox.ph/'
    }
    if _auth_token:
        headers['Authorization'] = _auth_token
    return headers

def _ensure_token():
    global _auth_token
    if _auth_token:
        return
    url = f"{API_BASE}/wefeed-h5api-bff/subject/search-suggest"
    resp = requests.post(url, headers=_get_headers(), json={"keyword": "avatar", "perPage": 0})
    x_user = resp.headers.get("x-user")
    if x_user:
        try:
            token = json.loads(x_user).get("token")
            if token:
                _auth_token = f"Bearer {token}"
        except:
            pass

def search(query):
    _ensure_token()
    url = f"{API_BASE}/wefeed-h5api-bff/subject/search"
    payload = {"keyword": query, "page": 1, "perPage": 20}
    resp = requests.post(url, headers=_get_headers(), json=payload)
    
    if resp.status_code != 200:
        return []
        
    try:
        data = resp.json()
        items = data.get('data', {}).get('items', [])
        if not items:
            items = data.get('data', {}).get('list', [])
            
        results = []
        for item in items:
            if 'subject' in item:
                item = item['subject']
                
            title = item.get('title', '')
            slug = item.get('detailPath', '')
            subjectId = item.get('subjectId', '')
            cover = item.get('cover', {})
            poster = cover.get('url', '') if isinstance(cover, dict) else ''
            
            if title and slug and subjectId:
                results.append({
                    'title': title,
                    'slug': slug,
                    'subjectId': subjectId,
                    'poster': poster
                })
        return results
    except Exception as e:
        return []

def get_episodes(slug, subjectId):
    _ensure_token()
    url = f"{API_BASE}/wefeed-h5api-bff/detail?detailPath={slug}"
    resp = requests.get(url, headers=_get_headers())
    
    episodes = []
    if resp.status_code != 200:
        return episodes
        
    try:
        data = resp.json().get('data', {})
        resource = data.get('resource', {})
        seasons = resource.get('seasons', [])
        
        if not seasons:
            return [{'title': 'Play Movie', 'se': 0, 'ep': 0}]
            
        for season in seasons:
            if not isinstance(season, dict): continue
            se = season.get('se', 0)
            max_ep = season.get('maxEp', 0)
            
            if max_ep == 0:
                return [{'title': 'Play Movie', 'se': 0, 'ep': 0}]
                
            for ep in range(1, max_ep + 1):
                episodes.append({'title': f'Season {se} Episode {ep}', 'se': se, 'ep': ep})
                
    except:
        pass
        
    return episodes

def get_stream(subjectId, detailPath, se, ep):
    _ensure_token()
    url = f"{API_BASE}/wefeed-h5api-bff/subject/play"
    params = {
        "subjectId": subjectId,
        "se": se,
        "ep": ep,
        "detailPath": detailPath
    }
    
    headers = _get_headers()
    headers['Referer'] = f"https://netfilm.world/spa/videoPlayPage/movies/{detailPath}?id={subjectId}&type=/movie/detail&detailSe=0&detailEp=0&lang=en"
    headers['x-client-info'] = '{"timezone":"Asia/Colombo"}'
    
    resp = requests.get(url, headers=headers, params=params)
    if resp.status_code != 200:
        return None
        
    try:
        data = resp.json().get('data', {})
        if data.get('hasResource') is False:
            return None
            
        sources = []
        sources.extend(data.get('streams', []))
        sources.extend(data.get('hls', []))
        
        if not sources:
            return None
            
        # Sort sources by resolution (e.g. 1080, 720, 480, 360) in descending order
        def get_res(s):
            res_str = str(s.get('resolutions', '0')).lower().replace('p', '')
            try:
                return int(res_str)
            except:
                return 0
                
        # Filter out VIP locked streams that have no URL
        sources = [s for s in sources if s.get('url')]
        if not sources:
            return None
        sources.sort(key=get_res, reverse=True)
        best_stream = sources[0].get('url')
        if not best_stream:
            return None
            
        kodi_headers = urllib.parse.urlencode({'Referer': headers['Referer'], 'User-Agent': UA})
        return f"{best_stream}|{kodi_headers}"
    except:
        return None



def get_home_sections():
    _ensure_token()
    url = f"{API_BASE}/wefeed-h5api-bff/home"
    resp = requests.get(url, headers=_get_headers())
    sections = []
    try:
        data = resp.json()
        ops = data.get('data', {}).get('operatingList', [])
        for op in ops:
            title = op.get('title')
            if title: title = title.encode('ascii', 'ignore').decode().strip()
            # Only include sections that have subjects and a title
            if title and op.get('subjects'):
                sections.append(title)
    except: pass
    return sections

def get_home_category(title_match):
    _ensure_token()
    url = f"{API_BASE}/wefeed-h5api-bff/home"
    resp = requests.get(url, headers=_get_headers())
    try:
        data = resp.json()
        ops = data.get('data', {}).get('operatingList', [])
        for op in ops:
            title = op.get('title', '')
            if title_match.lower() == title.lower():
                items = op.get('subjects', [])
                results = []
                for item in items:
                    if 'subject' in item: item = item['subject']
                    title = item.get('title', '')
                    slug = item.get('detailPath', '')
                    subjectId = item.get('subjectId', '')
                    poster = item.get('cover', {}).get('url', '') if isinstance(item.get('cover', {}), dict) else ''
                    if title and slug and subjectId:
                        results.append({'title': title, 'slug': slug, 'subjectId': subjectId, 'poster': poster})
                return results
    except: pass
    return []
