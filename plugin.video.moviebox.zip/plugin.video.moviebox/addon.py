import sys
import urllib.parse
import xbmcgui
import xbmcplugin
from resources.lib import moviebox_scraper

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

# xbmcplugin.setContent(addon_handle, 'movies')
action = args.get('action', [None])[0]

def build_url(query):
    return addon_url + '?' + urllib.parse.urlencode(query)

if action is None:
    # Main menu
    url_search = build_url({'action': 'search'})
    li_search = xbmcgui.ListItem('Search')
    li_search.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_search, listitem=li_search, isFolder=True)
    
    url_home = build_url({'action': 'home_menu'})
    li_home = xbmcgui.ListItem('Home')
    li_home.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_home, listitem=li_home, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_menu':
    sections = moviebox_scraper.get_home_sections()
    for sec in sections:
        url = build_url({'action': 'home_category', 'category': sec})
        li = xbmcgui.ListItem(sec)
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'home_category':
    category = args.get('category', [None])[0]
    
    results = moviebox_scraper.get_home_category(category)
    for item in results:
        url = build_url({'action': 'episodes', 'slug': item['slug'], 'subjectId': item['subjectId']})
        li = xbmcgui.ListItem(item['title'])
        if item.get('poster'): li.setArt({'thumb': item['poster'], 'poster': item['poster']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'search':
    query = xbmcgui.Dialog().input('Search')
    if query:
        results = moviebox_scraper.search(query)
        for item in results:
            url = build_url({'action': 'episodes', 'slug': item['slug'], 'subjectId': item['subjectId']})
            li = xbmcgui.ListItem(item['title'])
            if item.get('poster'):
                li.setArt({'thumb': item['poster'], 'poster': item['poster']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

elif action == 'episodes':
    slug = args.get('slug', [None])[0]
    subjectId = args.get('subjectId', [None])[0]
    
    # We will fetch details using Nuxt parsing in the scraper
    episodes = moviebox_scraper.get_episodes(slug, subjectId)
    
    for ep in episodes:
        url = build_url({'action': 'play', 'subjectId': subjectId, 'detailPath': slug, 'season': ep.get('se', 1), 'episode': ep.get('ep', 1)})
        li = xbmcgui.ListItem(ep['title'])
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

elif action == 'play':
    subjectId = args.get('subjectId', [None])[0]
    detailPath = args.get('detailPath', [None])[0]
    se = args.get('season', ['1'])[0]
    ep = args.get('episode', ['1'])[0]
    
    stream_url = moviebox_scraper.get_stream(subjectId, detailPath, se, ep)
    if stream_url:
        play_item = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('Error', 'Could not find a playable stream', xbmcgui.NOTIFICATION_ERROR)
