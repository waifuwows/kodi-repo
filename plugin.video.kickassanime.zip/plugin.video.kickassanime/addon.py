import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
from resources.lib import kaa_scraper

# Plugin setup
ADDON_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])

def build_url(query):
    return ADDON_URL + '?' + urllib.parse.urlencode(query)

def list_categories():
    categories = kaa_scraper.get_home_categories()
    for cat in categories:
        url = build_url({'action': 'list_anime', 'path': cat['path']})
        li = xbmcgui.ListItem(cat['title'])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    
    # Search button
    search_url = build_url({'action': 'search'})
    search_li = xbmcgui.ListItem("[COLOR yellow]Search Anime...[/COLOR]")
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=search_url, listitem=search_li, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_anime(path):
    anime_list = kaa_scraper.get_anime_list(path)
    for anime in anime_list:
        url = build_url({'action': 'list_episodes', 'slug': anime['slug']})
        li = xbmcgui.ListItem(anime['title'])
        if anime['image']:
            li.setArt({'thumb': anime['image'], 'icon': anime['image'], 'poster': anime['image']})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def search_anime():
    keyboard = xbmc.Keyboard('', 'Search for Anime')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        query = keyboard.getText()
        anime_list = kaa_scraper.search_anime(query)
        for anime in anime_list:
            url = build_url({'action': 'list_episodes', 'slug': anime['slug']})
            li = xbmcgui.ListItem(anime['title'])
            if anime['image']:
                li.setArt({'thumb': anime['image'], 'icon': anime['image'], 'poster': anime['image']})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(slug):
    details = kaa_scraper.get_anime_details(slug)
    if not details:
        xbmcplugin.endOfDirectory(HANDLE)
        return
        
    languages = ["ja-JP"]
    try:
        import requests
        lang_res = requests.get(f"https://kaa.lt/api/show/{slug}/language", headers=kaa_scraper.HEADERS)
        if lang_res.status_code == 200 and lang_res.json().get("result"):
            languages = lang_res.json()["result"]
    except:
        pass
        
    for lang in languages:
        lang_label = "Sub" if lang == "ja-JP" else ("Dub" if lang == "en-US" else lang)
        episodes = kaa_scraper.get_episodes(slug, lang)
        
        for ep in episodes:
            ep_title = f"Ep {ep.get('episode_string', '?')} - {ep.get('title') or 'Episode'} ({lang_label})"
            ep_slug = ep.get('slug')
            ep_num = ep.get('episode_string')
            
            if not ep_slug or not ep_num:
                continue
                
            url = build_url({'action': 'play_episode', 'slug': slug, 'ep_num': ep_num, 'ep_slug': ep_slug})
            li = xbmcgui.ListItem(ep_title)
            li.setProperty('IsPlayable', 'true')
            
            thumb = ""
            if ep.get('thumbnail'):
                thumb = kaa_scraper.format_poster(ep['thumbnail']).replace('poster', 'thumbnail')
            if thumb:
                li.setArt({'thumb': thumb, 'icon': thumb})
                
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def play_episode(slug, ep_num, ep_slug):
    stream = kaa_scraper.get_episode_stream(slug, ep_num, ep_slug)
    if not stream or not stream['manifest_url']:
        xbmcgui.Dialog().notification('Error', 'No stream found')
        return

    li = xbmcgui.ListItem(path=stream['manifest_url'])
    
    # Use inputstream adaptive for HLS/Dash
    li.setProperty('inputstream', 'inputstream.adaptive')
    if '.mpd' in stream['manifest_url']:
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    else:
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
    li.setProperty('inputstream.adaptive.manifest_headers', f"Origin={stream['origin']}&Referer={stream['referer']}&User-Agent={kaa_scraper.HEADERS['User-Agent']}")
    
    # Enable external subtitles if found
    if stream['subtitles']:
        sub_urls = []
        for sub in stream['subtitles']:
            sub_urls.append(sub['url'])
        li.setSubtitles(sub_urls)

    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)

def router(paramstring):
    action = paramstring.get('action', [''])[0]
    
    if not action:
        list_categories()
    elif action == 'list_anime':
        list_anime(paramstring.get('path', [''])[0])
    elif action == 'search':
        search_anime()
    elif action == 'list_episodes':
        list_episodes(paramstring.get('slug', [''])[0])
    elif action == 'play_episode':
        play_episode(
            paramstring.get('slug', [''])[0],
            paramstring.get('ep_num', [''])[0],
            paramstring.get('ep_slug', [''])[0]
        )

if __name__ == '__main__':
    router(ARGS)
