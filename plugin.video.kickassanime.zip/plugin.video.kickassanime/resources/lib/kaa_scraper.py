import requests
import json
import re

BASE_URL = "https://kaa.lt"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
}

def format_poster(poster_dict):
    if not poster_dict:
        return ""
    if poster_dict.get("hq"):
        return f"{BASE_URL}/image/poster/{poster_dict['hq']}.webp"
    if poster_dict.get("sm"):
        return f"{BASE_URL}/image/poster/{poster_dict['sm']}.webp"
    if poster_dict.get("url"):
        url = poster_dict["url"]
        return url if url.startswith("http") else f"{BASE_URL}/{url}"
    return ""

def get_home_categories():
    return [
        {"title": "Trending Anime", "path": "/api/show/trending"},
        {"title": "Popular Anime", "path": "/api/show/popular"},
        {"title": "Recent (All)", "path": "/api/show/recent?type=all"},
        {"title": "Recent (Sub)", "path": "/api/show/recent?type=sub"},
        {"title": "Recent (Dub)", "path": "/api/show/recent?type=dub"},
    ]

def get_anime_list(path, page=1):
    url = f"{BASE_URL}{path}"
    if "?" in url:
        url += f"&page={page}"
    else:
        url += f"?page={page}"
    
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return []
    
    data = res.json()
    results = data.get("result", [])
    
    parsed = []
    for item in results:
        title = item.get("title_en") or item.get("title") or "Unknown"
        slug = item.get("slug")
        image = format_poster(item.get("poster"))
        parsed.append({
            "title": title,
            "slug": slug,
            "image": image
        })
    return parsed

def search_anime(query, page=1):
    url = f"{BASE_URL}/api/fsearch"
    payload = {"page": page, "query": query}
    headers = HEADERS.copy()
    headers["Content-Type"] = "application/json"
    
    res = requests.post(url, json=payload, headers=headers)
    if res.status_code != 200:
        return []
    
    data = res.json()
    results = data.get("result", [])
    
    parsed = []
    for item in results:
        title = item.get("title_en") or item.get("title") or "Unknown"
        slug = item.get("slug")
        image = format_poster(item.get("poster"))
        parsed.append({
            "title": title,
            "slug": slug,
            "image": image
        })
    return parsed

def get_anime_details(slug):
    url = f"{BASE_URL}/api/show/{slug}"
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return None
    return res.json()

def get_episodes(slug, lang="ja-JP"):
    url = f"{BASE_URL}/api/show/{slug}/episodes?page=1&lang={lang}"
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return []
    
    data = res.json()
    episodes = data.get("result", [])
    pages = data.get("pages", [])
    
    if len(pages) > 1:
        for p in pages[1:]:
            page_num = p.get("number")
            if not page_num: continue
            ep_res = requests.get(f"{BASE_URL}/api/show/{slug}/episodes?page={page_num}&lang={lang}", headers=HEADERS)
            if ep_res.status_code == 200:
                episodes.extend(ep_res.json().get("result", []))
                
    return episodes

def get_episode_stream(slug, ep_num, ep_slug):
    url = f"{BASE_URL}/api/show/{slug}/episode/ep-{ep_num}-{ep_slug}"
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return None
    
    data = res.json()
    servers = data.get("servers", [])
    if not servers:
        return None
        
    for srv in servers:
        src = srv.get("src")
        if not src: continue
        
        # Format iframe url
        player_url = src.strip()
        if player_url.startswith("//"):
            player_url = "https:" + player_url
        elif player_url.startswith("/"):
            player_url = BASE_URL + player_url
            
        player_res = requests.get(player_url, headers={"User-Agent": HEADERS["User-Agent"], "Referer": f"{BASE_URL}/"})
        if player_res.status_code != 200:
            continue
            
        html = player_res.text
        html = html.replace("&quot;", '"')
        
        manifest_match = re.search(r'manifest":\[0,"(?:https?:)?(\/\/[^"]+)"]', html)
        if manifest_match:
            raw_manifest = manifest_match.group(1)
            manifest_url = raw_manifest if raw_manifest.startswith("http") else "https:" + raw_manifest
            
            # Subtitles regex
            subtitles = []
            track_matches = re.finditer(r'"language":\[\d+,"([^"]+)"][^}]+?"name":\[\d+,"([^"]+)"][^}]+?"src":\[\d+,"([^"]+)"]', html)
            for t in track_matches:
                lang = t.group(1)
                sub_name = t.group(2)
                sub_src = t.group(3).replace("\\/", "/")
                sub_url = sub_src if sub_src.startswith("http") else ("https:" + sub_src if sub_src.startswith("//") else BASE_URL + sub_src)
                subtitles.append({
                    "name": sub_name,
                    "lang": lang,
                    "url": sub_url
                })
                
            return {
                "manifest_url": manifest_url,
                "origin": player_url.split("/")[2] if "//" in player_url else BASE_URL.split("/")[2],
                "referer": player_url,
                "subtitles": subtitles
            }
            
    return None
